#!/bin/bash

stedgeai generate --model detect_remove_sig_per_channel.onnx --target stm32n6 --st-neural-art default@user_neuralart.json
cp st_ai_output/network.c .
cp st_ai_output/network_atonbuf.xSPI2.raw network_data.xSPI2.bin
arm-none-eabi-objcopy -I binary network_data.xSPI2.bin --change-addresses 0x70180000 -O ihex network_data.hex